Changelog détaillé :
<https://github.com/totoff974/JeeOrangeTv/commits/stable>

29-06-2019 21:30
===

-   Réduction du temps entre deux touches lors du zapping à 300ms
-   Activation de la vue mobile (identique au dash)

24-06-2019 16:10
===

-   ATTENTION CETTE MISE A JOUR NECESSITE DE RECREER LES EQUIPEMENTS !

05-06-2019 16:35
===

-   Fusion de la télécommande avec la mosaique avec ajout d'un effet slide 

04-06-2019 22:35
===

-   Refonte totale du plugin
-   Possibilité de créer des chaînes
-   Gestion des logos
-   Optimisation du code
-   Gestion des thèmes
-   Ajout de la fonction send EPG

31-01-2018 21:35
===

-   mise à jour de la documentation

01-10-2017 16:50
===

-   Modification style widget width:310px;height:480px

28-09-2017 10:15
===

-   Ajout des dépendances pour python
-	Lancement démon

27-09-2017 11:15
===

-   Création d'un point 0 mise en conformité du plugin
